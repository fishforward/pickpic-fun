#require 'active_record/connection_adapters/sqlite_adapter.rb'

module ActiveRecord
  module ConnectionAdapters
    SQLiteAdapter.class_eval do
      undef select if defined?(:select)

      protected
      def select(sql, name = nil)
        execute(sql, name).map do |row|
          record = {}
          row.each do |k, v|
            if k.is_a?(String)
              v.force_encoding(Encoding.default_external) if v.respond_to?(:force_encoding)
              record[k.sub(/^"?\w+"?\./, '')] = v
            end
          end
          record
        end
      end

    end
  end
end